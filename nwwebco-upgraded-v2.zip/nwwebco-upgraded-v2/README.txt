Northwest Web Co. — responsive static site

Deploy the contents of this folder to your web host.
The site is designed to work on iPhone, Android, tablet, laptop, and desktop widths.

Main contact: nwwebco@gmail.com
Instagram: @nwwebco
Website: https://nwwebco.com

Pricing shown: $250 base website, optional $25 on-page SEO add-on.
